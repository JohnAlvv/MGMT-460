let { MongoClient } = require("mongodb")
url = "mongodb://localhost:27017"
client = new MongoClient(url)
async function run () {
    try {
        await client.connect()
        database = client.db('Carpentry')
        table = database.collection('CRUD')
        query = {guestid: 9 }
        results = await table.deleteOne(query)
        console.log(`# Records deleted: ${result.deletedCount}`)
    } finally {
        await client.close();
    }
    }
    run().catch(console.dir)
