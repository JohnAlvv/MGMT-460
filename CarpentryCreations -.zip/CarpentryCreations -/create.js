let { MongoClient } = require("mongodb")
url = "mongodb://localhost:27017"
client = new MongoClient(url)
async function run () {
    try {
        await client.connect()
        database = client.db('Carpentry')
        table = database.collection('CRUD')
        record = {
            guestid      :9,
            guestname    :"test",
            guestdate :08/19/2022,
            guesttime     : 2,
            guesttitle :"test",
            guestmaterials    :"test",
            guesttools :"test",
            guestinstructions :"THIS IS A TEST"

        }
        result = await table.insertOne(record)
        console.log(`Record _id: ${result.insertedId} inserted!`) 
    } finally {
        await client.close()
    }
    }
    run().catch(console.dir);
