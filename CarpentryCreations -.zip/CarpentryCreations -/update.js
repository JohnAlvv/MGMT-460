let { MongoClient } = require("mongodb")
url = "mongodb://localhost:27017"
client = new MongoClient(url)
async function run () {
    try {
        await client.connect()
        database = client.db('Carpentry')
        table   = database.collection('CRUD')
        where   = {guestid: 1 }
        changes = {$set:{guesttitle:"Hanging Bottle Opener"}}
        result  = await table.updateOne(where,changes)
        console.log(`# Records Modified: ${result.modifiedCount};)`)
    } finally {
        await client.close();
    }
    }
    run().catch(console.dir)
